    //   ////////////  /////////////    ////    ////	    /////////////   //////	    //  ////////////////     /////      ///////
   //       //        //	           //  // // //  	   //	     //    //	   //	//           //    //    //    //
  //       //        ///////          //   //   //  	  ///////	    //     //	  //         //          //       //  //////
 //       //        //	         //	     //  	 //	   //    //	 //         //           //      //  ////
//       //        /////////////    //	    //   	/////////////   ////// 	//         //             ///////   //  ///
Created by thethethethe
I saw a need for this as it's actually one of the GBA tools that isn't in common sharing.
May be posted anywhere, only must keep all below files together
If you have any suggestions please let me know.
-Readme.txt
-Item Editor.exe
-Item Editor.exe.manifest

Supports English Versions of:
Fire Red
Leaf Green
Ruby
Sapphire
Emerald
If you want another language let me know.

Credits:
Hackmew for clscommondialog class module taken from APE
Darthatron for Hex Editing Functions Module taken from his tutorial
Elitemap Creators, mdlTextSapp module taken from Elitemap Source.