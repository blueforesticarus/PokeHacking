Esta herramienta ha sido subida por Rey Boo exclusivamente para Pok�mon Johto.

El creador original de esta herramienta es Wichu, puedes encontrar el hilo oficial aqu�:
http://www.pokecommunity.com/showthread.php?t=196143&page=4

No robar :P
---------------------------------------------------------------
Questo tool � stato compatibilizzato con le ROM italiane da JackHack96

http://www.hackromtools.altervista.org/