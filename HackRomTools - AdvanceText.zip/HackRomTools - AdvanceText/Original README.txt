                                                                                      
                                                                                      
                 **                                                                  *
      *         **                                         *******                 ** 
     **      ** ** **    *  ****   ** **    **    ***        ***     ***  **    * ****
    ****    ** *** **   *      **  *** *   ***   ** *        ***    ** *   **  *   ** 
   # ###   ##  ##   ## #   #####  ##  ##  ##    #####       ###    #####    ###   ##  
  #  ###   ##  ##   ###   ##  ##  ##  ##  ##    ##    ####  ###    ##      ###    ##  
 ########  ## ###   ##    ## ###  #   #   ###   ## #        ###    ## #   #  ##   ### 
#    ####  #####    #     #####  ##  ##   ##    ###        ###     ###  ##    ##  ##  

					Version 3.1.1
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


               �                                                �
               �                   ��������                     �
              ���           ��   ���  ��                       ���
      � ��������������� �  �� � ��  � ��  ���� ����        �����������
          �����������      �� � ��  � �� ��    ��             �����
            �������        �� � ��  � �� ���   ���            �� ��          
            ��� ���        �� � ��  � �� ��      ��          ��   ��
           ���   ���       �� �  ���  ��  ���� ����         �       �
           ��     ��
          �         �


!!! WARNING: I TAKE NO RESPONSIBILITY FOR ANYTHING THIS PROGRAM COULD OR COULD NOT DO TO YOU OR YOUR COMPUTER !!!

Revision:
- changed GUI to final look
- added some commands (like [PLAYER], [RIVAL]...)
- fixed some bugs
- decided to let it as a Japanese Viewer only
- changed About screen
- most parts recoded
- changed codename to Devastator
- added possibility to search for Japanese texts
- now changes re-occuring pointers
- fixed bug with Prolouge in Fire-Red/Leaf-Green ; Added Special Dialog box
- now program jumps automaticly to the beginning of a text
- improved right-click menu
- slowed down speed of the scrolling credits
- here and there some improvement
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
3.0.8
- added online update
- added another easter egg
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
3.0.9
- added character counter
- added check of missing folders/files
- added a feature to the save procedure, it now checks if there's enough space behind the current text before it repoints
- fixed bug with character counting
- cleaned up
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
3.0.14 (internal PokeCommunity preview release)
- added full support for spanish characters
- optimized GUI
- optimized file handling
- added help feature
- added Textbox-Script inserter
- added info to INI files
- bugfixes
- updated about screen
- when loading a japanese rom, the Japanese table will automatically be used
- disabled Live-Update in this version
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
3.1.0
- changed some stuff I forgot to list and can't remember o.o
- optimized coding some more
- added selection combobox to "Add Offset" dialog
- added possibility to delete entrys from the INIs and un-easteregged the "Add offset" dialog
- some other things optimized I forgot o.o
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
3.1.1
- fixed Live-Update bug (Thanks Li-Kero)


TODO:
- NUFFIN' ^_^

TO BE CONTINUED...?

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
