********************************************
***    Advance Map Ver 1.95 - English    ***
********************************************

This program is for the editing of Map, movement permissions, block data, events and wild pokemon data.
A block editor is also available.
It is compatible with all version of Pok�mon Advance in all languages.


.:|IMPORTANT|:.
-^-^-^-^-^-^-
This program was programmed by LU-HO Pok� and is consequently copyrightED by LU-HO Pok�!
If you downloaded it from another place then from http://amneu.no-ip.info, from www.LU-HO.ch.vu, ampage.no-ip.info or from romresources.net, please tell me right away! (luhopoke@gmail.com)


********************************
***          Greets          ***
********************************
A huge greeting goes to:
Jigglypuff for the Source of Goldmap2 Beta
and Jay, who gave it to me.

Further greets go to:
Tauwasser and F-Zero for their tutorials.
Mikaron for his work.
Serwe for giving me a few ideas.
Mulle who pointed me to a mistake.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun for the translations of the inis.
And of course, Filb for his board.
Another tahnk you goes out to F-Zero who helped me with the Sprite-Pallets.
Also dark01 received a big thank you for his help with the Sprites.
Thanks to evilboy for his help at the FAQs.
Another thanks goes to Scizz, dark01, BlueSonic and F-Zero for the Beta tests.
Aruka and perappu music list extension.
A big thanks goes to Mastermind_X for the structure of the Word Map data and for helping me make use of it.
A big thanks to Tutti for his great beta testing and extension of the behaviour data.
Tauwasser, Scizz, Satry, Ashly138, Anthony, wakachamo, HackMew, Christos, Martin�, Sebbe17/Jungleman, 44tim44 for the new translations of the INIs.
The Lazarus Development Team, for this genial OpenSource Development Environment.
Kiyron for extentions on FR/LG Music liste.
prime for his SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV for the Beta tests on AM 1.95.
