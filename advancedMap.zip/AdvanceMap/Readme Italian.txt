﻿********************************************
***     Advance Map v1.95 - Italiano     ***
********************************************
Questo programma consenta la modifiche delle mappe, dei permessi, dei blocchi, degli eventi e dei Pokémon selvatici.
AM funziona con tutte le ROM della serie Advance, tutte le lingue.
Ora è possibile anche cambiare le informazioni relative la mappa del mondo.


.:|IMPORTANTE|:.
-^-^-^-^-^-^-
Questo programma è stato programmato da LU-HO ed è soggetto ai diritti d'autore di LU-HO Poké!
Advance Map deriva dalla versione beta di GoldMap 2, creata da Jiggly.
Se non hai scaricato il file da http://amneu.no-ip.info, www.LU-HO.ch.vu, ampage.no-ip.info, romresources.net oppure da
www.romhackersworld.de.vu contattami al più presto! La mia mail è: luhopoke@gmail.com


*********************************
***      Ringraziamenti       ***
*********************************
Un grosso saluto va a:
BlueSonic(alias Jigglypuff) per la sorgente di Goldmap2 Beta
e Jay, che me l'ha fornita.

Ulteriori rigraziamenti:
Tauwasser e F-Zero per i loro tutorial.
Mikaron per il suo lavoro.
Serwe per qualche idea.
Mulle che mi ha segnalato un errore.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun per la traduzione degli INI.
E naturalmente Filb per il suo forum.
Un altro ringraziamento a F-Zero per avermi aiutato con le palette degli sprite.
Stesso discorso per dark01 che mi ha aiutato con gli sprite.
evilboy per l'aiuto alle FAQ.
Ancora una volta grazie a Scizz, dark01, BlueSonic e F-Zero per il betatesting.
Aruka e perappu per la loro estensione della lista della musica.
Un enorme grazie a Mastermind_X che ha trovato il modo di modificare la mappa del mondo e che mi ha aiutato ad implementarne la funzione.
Un altro grazie a Tutti per le sue super prestazioni nel besta testing e per la lista del comportamento dei vari blocchi.
Infine un grazie a Tauwasser, Scizz, Satry, Ashly138, Anthony, wakachamo, HackMew, Christos, Martin², Sebbe17/Jungleman, 44tim44 per le nuove traduzioni.
The Lazarus Development Team, for this genial OpenSource Development Environment.
Kiyron for extentions on FR/LG Music liste.
prime for his SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV for the Beta tests on AM 1.95.
