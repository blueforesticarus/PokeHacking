﻿********************************************
*** Advance Map Ver 1.95 - Francais      ***
********************************************

Ce programme est destiné à permettre de modifier les cartes, les mouvements possibles, les évènements et les informations relatives aux Pokémons sauvages qui apparaissent.
Dans le futur, les informations liées aux collisions (c-à-d les rencontres avec un objet, en se placant dessus en marchant) pouront aussi être modifiées.
It is compatible with all version of Pokémon Advance 
in all languages.


.:|IMPORTANT|:.
-^-^-^-^-^-^-^-
Ce programme a été écrit par LU-HO Poké, et de ce fait, Copyright LU-HO Poké !
Si vous l'avez téléchargé d'un autre site que de http://amneu.no-ip.info, www.LU-HO.ch.vu, ampage.no-ip.info, romresources.net
merci de me le signaler. Mon adresse e-mail est: luhopoke@gmail.com


********************************
***      Remerciements       ***
********************************
Les plus grand remerciements vont à Jigglypuff pour le Code Source de Goldmap2 Beta et à Jay, qui me l'a transmis.

Que soient aussi remerciés :
Tauwasser et F-Zero pour leurs tutoriaux.
Mikaron pour ses travaux.
Serwe qui m'a apporté quelques idées.
Mulle qui m'a signalé une erreur dans le programme.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun pour leurs traductions des fichiers ini.
Et bien sûr Filb pour son Board.

Un autre grand merci à F-Zero qui m'a aidé sur les Palettes de Sprites.
Merci également à dark01 pour son aide sur les Sprites.
Merci à evilboy for son aide sur les FAQs.

Un dernier grand merci pour Scizz, dark01, BlueSonic et F-Zero pour leur rôle de béta-testeurs.
Aruka and perappu music list extension.
A big thanks goes to Mastermind_X for the structure of the Word Map data and for helping me make use of it.
A big thanks to Tutti for his great beta testing and extension of the behaviour data.
Tauwasser, Scizz, Satry, Ashly138, Anthony, wakachamo, HackMew, Christos, Martin², Sebbe17/Jungleman, 44tim44 for the new translations of the INIs.
The Lazarus Development Team, for this genial OpenSource Development Environment.
Kiyron for extentions on FR/LG Music liste.
prime for his SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV for the Beta tests on AM 1.95.
