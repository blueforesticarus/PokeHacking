﻿*********************************************
***          Advance Map Ver 1.95         ***
*********************************************
Dieses Programm ist für das Editieren von Maps, Gehdaten, Blockdaten, Events und Wildepokemondaten.
Man kann diese Daten editieren oder dem Spiel neue Daten hinzufügen.
Es ist auch ein Blockeditor enthalten
AM läuft mit allen Pokemon Roms der AdanceVersion, in allen sprachen.



.:|WICHTIG|:.
-^-^-^-^-^-^-
Dieses Programm wurde von LU-HO Poké programmiert und ist somit Copyright by LU-HO Poké!
Dies wurde von Jiggly (programmierer von Goldmap 2 Beta) Officiel bestätigt.
Wen Sie AM von einem anderen Ort, als direkt bei http://amneu.no-ip.info, von www.LU-HO.ch.vu, ampage.no-ip.info oder von
romresources.net runtergeladen habt, richtet mir das Bitte per E-Mail aus! (luhopoke@gmail.com)


*********************************************
***          Grüsse/Danksagungen          ***
*********************************************
Der grösste Dank geht an:
BlueSonic(alias Jigglypuff) für den Source von Goldmap2 Beta
und Jay, der ihn übermittelt hat.

Weitere grüsse gehen an:
Tauwasser und F-Zero für Ihre Tuts.
Mikaron für seine Dienste.
Serwe der mich auf ein paar Ideen gebracht hat.
Mulle die mich auf einen Feher hinwies.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun für die Übersetzungen der ini's.
Und natürlich Filb für sein Board.
Ein Weiterer Dank geht an F-Zero der mir bei den Paletten für die Sprites sehr geholfen hat.
Auch an dark01 geht für seine hilfe bei den Sprites einen grossen Dank.
An evilboy geht ein Dank für die Hilfe bei den FAQ's.
Nochmals ein dank geht an Scizz, dark01, BlueSonic und F-Zero für die Betatests.
Aruka und perappu für die Musiklisten Erweiterungen.
Ein grosser Dank geht an Mastermind_X welcher den Aufbau der Weltkarten Daten rausgefunden hat und mir bei der Umsetzung geholfen hat.
Einen grossen Dank an Tutti für seine super Betatest-Leistung und die Erweiterung der Verhaltensbyteliste.
Tauwasser, Scizz, Satry, Ashly138, Anthony, wakachamo, HackMew, Christos, Martin², Sebbe17/Jungleman, 44tim44 für die neuen Übersetzungen der ini's.
Das Lazarus Entwickler Team, für die geniale OpenSource Entwicklungsumgebung.
Kiyron für erweiterung der FR/LG Musikliste.
prime für das SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV für die Betatests von AM 1.95.