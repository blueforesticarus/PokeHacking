﻿******************************************************
*** Advance Map Versão 1.95 - Português Brasileiro ***
******************************************************

Este programa é para a edição do mapa, das permissões do movimento, dos dados do bloco, 
dos eventos e de dados selvagens do pokemon. Uns dados mais atrasados da colisão devem 
também ser editáveis. Funciona com a Geração Advanced Pokémon (R/S/E/FR/LG),
in all languages.     


.:|IMPORTANTE|:.
-^-^-^-^-^-^-^-
Este programa foi programado por Lu-ho Poké
e conseqüentemente seu copyright pertence a ele!  
Se você fez o download de um outro lugar que não seja 
http://amneu.no-ip.info, www.LU-HO.ch.vu, ampage.no-ip.info, romresources.net
diga-me por favor! Meu email é: luhopoke@gmail.com


A parte que fala dos INIs foi cortada dessa tradução


********************************
***      Agradecimentos      ***
********************************
Agradecimentos maiores para:
Jigglypuff pelo Source do Goldmap2 Beta
e Jay, que me entregou.

O resto dos agradecimentos:
Tauwasser e F-Zero pelos tutoriais.
Mikaron pelo seu trabalho.
Serwe por me dar idéias.
Mulle que me fez errar.
Scizz, Timhay, GruntZ, Ashly138, Usohachi, BlueSonic, Sylph, Liquid_Thunder, IIIMQIII, Netto-kun e outros pela tradução dos INIs.
And e é claro, Filb por seu fórum.
Outro agradecimento vai para F-Zero que me ajudou me com as Sprite-Pallets.
Também dark01 recebeu um grande obrigado pela ajuda com os sprites.
Obrigado a evilboy pela ajuda com os FAQs.
Mais agradecimento para Scizz, dark01, BlueSonic and F-Zero pelos BetaTests.
Aruka and perappu music list extension.
A big thanks goes to Mastermind_X for the structure of the Word Map data and for helping me make use of it.
A big thanks to Tutti for his great beta testing and extension of the behaviour data.
Tauwasser, Scizz, Satry, Ashly138, Anthony, wakachamo, HackMew, Christos, Martin², Sebbe17/Jungleman, 44tim44 for the new translations of the INIs.
The Lazarus Development Team, for this genial OpenSource Development Environment.
Kiyron for extentions on FR/LG Music liste.
prime for his SeasonSystem.
Dragonflye, Aeonos, haefele, prime, Tutti, skyfall, pokemontutorialTV for the Beta tests on AM 1.95.
