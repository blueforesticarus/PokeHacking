*################################*
#     Advance-Mart Evolution     #
#          Version 6.5.2         #
#     Copyright 2004 by Scizz    #
#				 #
# your rights:			 #
# - allowed to use the program   #
# - allowed to TRANSLATE texts   ############################*
# - NOT allowed to change copyright (texts, graphics etc.)   #
# - NOT allowed to put it up for Download without permission #
#                                ############################*
*################################*

Revision:
- changed GUI for item editing
- improved item editor (interdpth, check this out! ;-)
- added support for POK�MON Emerald
- upgraded to Version: Evolution
- added offsets for english Ruby, Sapphire
- replaced german word in readme file
- completely re-coded search function! gotta see it! :-D
- IMPROVED SPEED!!!

~ 6.5.0 (internal)~
- fixed emerald bugs
- updated about screen & online update
- added description pointer editor field in Item Editor

~ 6.5.1 (public) ~
- Changed Version to 2005
- changed codename to Revolution
- changed GUI
- changed Item Editor GUI + got rid of the description offset field (Doubleclick on the description to change its offset)
- lots of code improvement (more to come)
- increased speed
- added Item name editing (doubleclick on the item name in the list in the Item-Editor.)

~ 6.5.2 ~
- fixed spelling mistake >.<
- added missing offsets


NOTE:
- Current offsets: Ruby/Sapphire (German, English)
		   Fire-Red (German, English, Japanese)
		   Leaf Green (Japanese)
		   Emerald (English, Japanese)

TODO:
- check for bugz
- do things I can't think of at the moment o.O

=========================================================
Instructions:

=======
Main dialog:
=======
To edit the items of a Mart just load the ROM of your choice.
Then select the City with the Mart you want to edit from the Dropdown Box on the Map.
Next click on a POK�BALL to edit the selected Item. (It's NOT possible to add new Items!!!)
When you're done just click the Save button.

=======
Item Editor:
=======
To edit the price of an item you have to choose an item from the list displayed.
Next you'll see the current price in the Old price box.
If you want to change it just type your new price in the New price box.
Then you have to click on "Menu" -> "Save..." to save the changes you've made.
You have to do this for EVERY item you change.
To get back to Advance-Mart just click on "Menu" -> "Back to Advance-Mart | 2005".

=======
Mart search:
=======
To serach for Marts you have to select the Items a Mart sells from the dropdown boxes.
Then click on "Search Mart" to start your search.
If the Items are found the Message "Items found at offset: (dec offset) Dec." will appear in the "Summary" box.
If no items are found the message "No Items found" will appear.

=========================================================

OK I hope I made this German prog a bit more useable for foreign users.

so long,

Scizz